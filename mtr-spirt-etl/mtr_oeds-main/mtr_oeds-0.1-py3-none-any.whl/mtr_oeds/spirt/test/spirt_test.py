from mtr_oeds.spirt.spirt import SpirtReport
x = SpirtReport()
x.spirt_end2endProcess()
