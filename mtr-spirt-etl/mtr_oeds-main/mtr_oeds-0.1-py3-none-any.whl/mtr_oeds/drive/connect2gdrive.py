def test_add_1(x):
    return x+1
